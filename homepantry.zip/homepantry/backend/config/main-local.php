<?php

$config = [
    'components' => [
        'request' => [
            'cookieValidationKey' => 'ZapnUn-q5dwZA6otrim5Md2-YNOnb96m',

            // INTERPRETA A API
            'parsers' => [
                'application/json' => [
                    'class' => 'yii\web\JsonParser',
                ],
            ],
        ],
    ],
];

if (!YII_ENV_TEST) {
    $config['bootstrap'][] = 'debug';
    $config['modules']['debug'] = [
        'class' => \yii\debug\Module::class,
    ];

    $config['bootstrap'][] = 'gii';
    $config['modules']['gii'] = [
        'class' => \yii\gii\Module::class,
    ];
}

return $config;

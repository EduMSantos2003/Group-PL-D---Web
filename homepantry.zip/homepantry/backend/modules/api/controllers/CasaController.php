<?php

namespace backend\modules\api\controllers;

use yii\rest\ActiveController;

class CasaController extends ActiveController
{
    public $modelClass = \common\models\Casa::class;
}

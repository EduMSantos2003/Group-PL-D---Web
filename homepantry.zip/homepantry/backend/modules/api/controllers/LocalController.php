<?php

namespace backend\modules\api\controllers;

use yii\rest\ActiveController;

class LocalController extends ActiveController
{
    public $modelClass = 'common\models\Local';
}
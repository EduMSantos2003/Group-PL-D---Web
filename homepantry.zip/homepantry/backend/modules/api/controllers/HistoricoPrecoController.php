<?php

namespace backend\modules\api\controllers;

use yii\rest\ActiveController;

class HistoricoPrecoController extends ActiveController
{
    public $modelClass = 'common\models\HistoricoPreco';
}
